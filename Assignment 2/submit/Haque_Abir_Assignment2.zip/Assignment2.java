import java.util.LinkedList;

public class Assignment2 {
    public static void main(String args[]){
        inputReader r = new inputReader();
        r.openFile();
        r.readFile();
        r.closeFile();
    }
}
