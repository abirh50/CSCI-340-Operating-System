public class PCB_structure {
    private int parentInd;
    private int child;

    public PCB_structure(int p, int c) {
        this.parentInd = p;
        this.child = c;
    }
}
