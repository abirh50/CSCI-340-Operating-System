import java.util.Random;

public class Assignment1 {
    public static void main(String args[]){
        Random rand = new Random();
        Kolonel kol = new Kolonel();
        kol.Create(-1);
    }
}
